#!/bin/bash
rm -r ~/nex/apps/Evolve
rm ~/.local/share/applications/evolve.desktop
echo "Done"
